package com.DisplayProduct.DisplayProduct;

import java.util.ArrayList;

public class Supply {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList supply = new ArrayList<>();
		supply.add("Product1");
		supply.add ("2021-03-16T08:53:48.616Z");
		supply.add ("10");
		
		
		ArrayList supply1 = new ArrayList<>();
		supply1.add("Product2");
		supply1.add ("2021-03-16T08:59:48.616Z");
		supply1.add ("5");

	

	
		
	}

}
