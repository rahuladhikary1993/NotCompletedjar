package com.DisplayProduct.DisplayProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisplayProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
